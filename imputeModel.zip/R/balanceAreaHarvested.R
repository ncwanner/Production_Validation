##' Function to compute area harvested when new production and yield are given.
##' 
##' @param data The data.table object containing the data.
##' @param processingParameters A list of the parameters for the production 
##'   processing algorithms.  See defaultProductionParameters() for a starting 
##'   point.
##' @param newObservationFlag The flag which should be placed for computed 
##'   observations as the observation flag.
##' @param newMethodFlag The flag which should be placed for computed 
##'   observations as the method flag.
##' @param unitConversion Yield is computed as (production) / (area) and 
##'   multiplied by unitConversion.  This parameter defaults to 1.
##'   
##' @export
##' 

balanceAreaHarvested = function(data, processingParameters,
                             newObservationFlag = "I", newMethodFlag = "i",
                             unitConversion = 1){
    
    ### Data Quality Checks
    if(!exists("ensuredProductionData") || !ensuredProductionData)
        ensureProductionInputs(data = data,
                               processingParameters = processingParameters)

    ### Save clutter by renaming "processingParameters" to "p" locally.
    p = processingParameters
    data[get(p$areaHarvestedObservationFlag) == "M" &
         get(p$areaHarvestedMethodFlag) == "u",
         c(p$areaHarvestedValue) := NA]

    
    ### Impute only when area and yield are available and production isn't
    filter = data[,is.na(get(p$areaHarvestedValue)) & # area is missing
                  !is.na(get(p$yieldValue)) &         # yield is available
                  !is.na(get(p$productionValue))]     # production is available
    
    data[filter, c(p$areaHarvestedValue) :=
             sapply(computeRatio(get(p$productionValue), get(p$yieldValue)) *
                        unitConversion, roundResults)]
    data[filter, c(p$areaHarvestedObservationFlag) := newObservationFlag]
    ## Wrap last call in invisible() so no data.table is returned
    invisible(data[filter, c(p$areaHarvestedMethodFlag) := newMethodFlag])
}
